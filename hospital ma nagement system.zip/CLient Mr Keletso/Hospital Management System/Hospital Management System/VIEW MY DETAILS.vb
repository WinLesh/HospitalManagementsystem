﻿Imports System.IO
Imports System.Data.SqlClient

Public Class VIEW_MY_DETAILS
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim comstring As String
    Public myreader As SqlDataReader

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        RECEPTIONIST_VIEW.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub VIEW_MY_DETAILS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=.\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()

            ' MsgBox("System Ready", MsgBoxStyle.Information)
        End If
    End Sub

    Sub load_details()
        Dim querystring As String = "SELECT * FROM staff_details WHERE id ='" & TextBox10.Text & "'"
        Dim cmd As New Data.SqlClient.SqlCommand(querystring, obj_conc)
        ' Dim tbl_enq As New DataTable

        myreader = cmd.ExecuteReader()
        If myreader.Read Then
            TextBox1.Text = myreader("id")
            TextBox2.Text = myreader("fname")
            TextBox3.Text = myreader("sname")
            TextBox11.Text = myreader("DOB")
            TextBox12.Text = myreader("Emp_Type")
            TextBox13.Text = myreader("Gender")
            TextBox14.Text = myreader("salary")
            TextBox4.Text = myreader("Physical_Ad")
            TextBox5.Text = myreader("Email")
            TextBox6.Text = myreader("Physical_Ad")
            TextBox7.Text = myreader("Contact_No")
            TextBox8.Text = myreader("Contact2")
            TextBox9.Text = myreader("Leave")
            TextBox15.Text = myreader("Reg_Date")

            ' MsgBox("Success")
            ' btn_proceed.Enabled = True
            'btn_save.Enabled = False
        Else
            MsgBox("Sorry an Error occured in attemting to read the data", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        load_details()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        WELCOME.Show()
        Me.Hide()

    End Sub
End Class
﻿Imports System.IO
Imports System.Data.SqlClient

Public Class REGISTRATION
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim comstring As String

    Private Sub REGISTRATION_Load(sender As Object, e As EventArgs) Handles MyBase.Load
         If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=DESKTOP-9MTGMII\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()

        End If
        TextBox9.Text = 20
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Me.Close()
        WELCOME.Show()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        WELCOME.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Or ComboBox2.Text = "" Or ComboBox3.Text = "" Or TextBox4.Text = "" _
            Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Or TextBox8.Text = "" Or TextBox9.Text = "" Then
            MsgBox("Please fill in all the details", MsgBoxStyle.Critical)
        Else
            save_details()
            'save_depart()
            'credentials()
        End If
    End Sub

    Sub save_details()
        If TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox3.Text <> "" And ComboBox1.Text <> "" And ComboBox2.Text <> "" And ComboBox3.Text <> "" _
            And TextBox4.Text <> "" And TextBox5.Text <> "" And TextBox6.Text <> "" And TextBox7.Text <> "" And TextBox8.Text <> "" Then




            With obj_com
                .Connection = obj_conc

                .CommandText = "INSERT INTO staff_details (id, fname, sname, DOB, Emp_type, gender, salary, Postal_Ad, Email, Physical_Ad, Contact_No, Contact2, Leave, Reg_Date) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" _
                & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" _
                & DateTimePicker2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Request recorded successfully", MsgBoxStyle.Information)
                ' btn_proceed.Enabled = True
                'save_depart()
                credentials()

            End With
            'Else
            '    If TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox2.Text = "" Or TextBox3.Text = "" Then
            '        MsgBox("fill in all details", MsgBoxStyle.Information)
            '    End If
            ' obj_conc.Close()
        End If
        save_depart()
    End Sub

    Sub save_depart()
        If ComboBox1.Text = "Administrator" Then
            With obj_com
                .Connection = obj_conc
                .CommandText = "Insert Into Admin (id, fname, sname, DOB, Emp_type, gender, salary, Postal_Ad, Email, Physical_Ad, Contact_No, Contact2, Leave,Reg_Date) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" _
                & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" _
                & DateTimePicker2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Administrator Added Successfully")
            End With
        ElseIf ComboBox1.Text = "Doctor" Then
            With obj_com
                .Connection = obj_conc
                .CommandText = "Insert Into Doctor_d (id, fname, sname, DOB, Emp_type, gender, salary, Postal_Ad, Email, Physical_Ad, Contact_No, Contact2, Leave, Reg_Date) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" _
                & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" _
                & DateTimePicker2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Doctor Added Successfully")
            End With

            Elseif ComboBox1.Text = "Human Resource" Then
            With obj_com
                .Connection = obj_conc
                .CommandText = "Insert Into HR (id, fname, sname, DOB, Emp_type, gender, salary, Postal_Ad, Email, Physical_Ad, Contact_No, Contact2, Leave, Reg_Date) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" _
                & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" _
                & DateTimePicker2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("HR Added Successfully")
            End With

            'ElseIf ComboBox1.Text = "Nurse" Then
            '    With obj_com
            '        .Connection = obj_conc
            '        .CommandText = "Insert Into Nurse_d (id, fname, sname, DOB, Emp_type, gender, salary, Postal_Ad, Email, Physical_Ad, Contact_No, Contact2, Leave, Reg_Date) VALUES ('" _
            '        & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" _
            '        & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" _
            '        & DateTimePicker2.Text & "')"
            '        .ExecuteNonQuery()
            '        MsgBox("Nurse Added Successfully")
            '    End With

        ElseIf ComboBox1.Text = "Pharmacist" Then
            With obj_com
                .Connection = obj_conc
                .CommandText = "Insert Into Pharmacist_d (id, fname, sname, DOB, Emp_type, gender, salary, Postal_Ad, Email, Physical_Ad, Contact_No, Contact2, Leave, Reg_Date) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" _
                & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" _
                & DateTimePicker2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Pharmacist Added Successfully")
            End With

        ElseIf ComboBox1.Text = "Receptionist" Then
            With obj_com
                .Connection = obj_conc
                .CommandText = "Insert Into Recept (id, fname, sname, DOB, Emp_type, gender, salary, Postal_Ad, Email, Physical_Ad, Contact_No, Contact2, Leave, Reg_Date) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & ComboBox1.Text & "','" & ComboBox2.Text & "','" & ComboBox3.Text & "','" _
                & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" _
                & DateTimePicker2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Receptionist Added Successfully")
            End With
        End If
        'End If
        'End If
        'End If
        'End if
    End Sub

    Sub credentials()
        With obj_com
            .Connection = obj_conc
            .CommandText = "Insert Into slogin (username, password_, Emp_type) VALUES ('" _
            & TextBox5.Text & "','" & TextBox1.Text & "','" & ComboBox1.Text & "')"
            .ExecuteNonQuery()
            MsgBox("Username is " & TextBox5.Text & " Password is " & TextBox1.Text)
        End With
    End Sub

End Class
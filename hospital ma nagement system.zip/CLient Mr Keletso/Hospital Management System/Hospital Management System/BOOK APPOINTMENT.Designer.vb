﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BOOK_APPOINTMENT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.avail_view = New System.Windows.Forms.ListView()
        Me.fname = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.avail = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.DoctordBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HmsDataSet1 = New Hospital_Management_System.hmsDataSet1()
        Me.HmsDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HmsDataSet = New Hospital_Management_System.hmsDataSet()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Doctor_dTableAdapter = New Hospital_Management_System.hmsDataSet1TableAdapters.Doctor_dTableAdapter()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        CType(Me.DoctordBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HmsDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HmsDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HmsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'avail_view
        '
        Me.avail_view.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.fname, Me.avail})
        Me.avail_view.Location = New System.Drawing.Point(146, 452)
        Me.avail_view.Name = "avail_view"
        Me.avail_view.Size = New System.Drawing.Size(765, 157)
        Me.avail_view.TabIndex = 68
        Me.avail_view.UseCompatibleStateImageBehavior = False
        Me.avail_view.View = System.Windows.Forms.View.Details
        '
        'fname
        '
        Me.fname.Text = "DOCTOR'S FULL NAME (s)"
        Me.fname.Width = 296
        '
        'avail
        '
        Me.avail.Text = "AVAILABILITY STATUS"
        Me.avail.Width = 220
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Lucida Calligraphy", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(408, 403)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(240, 27)
        Me.Label8.TabIndex = 67
        Me.Label8.Text = "DOCTORS' STATUS"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Lucida Calligraphy", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(39, 263)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 27)
        Me.Label4.TabIndex = 74
        Me.Label4.Text = "SURNAME"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Lucida Calligraphy", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(39, 208)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(176, 27)
        Me.Label3.TabIndex = 73
        Me.Label3.Text = "FIRST NAME"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Lucida Calligraphy", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(39, 154)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(169, 27)
        Me.Label2.TabIndex = 72
        Me.Label2.Text = "ID NUMBER"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(261, 267)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(226, 22)
        Me.TextBox3.TabIndex = 71
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(261, 213)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(226, 22)
        Me.TextBox2.TabIndex = 70
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(261, 159)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(226, 22)
        Me.TextBox1.TabIndex = 69
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(580, 163)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 17)
        Me.Label1.TabIndex = 75
        Me.Label1.Text = "DOCTOR"
        '
        'ComboBox1
        '
        Me.ComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.DoctordBindingSource, "sname", True))
        Me.ComboBox1.DataSource = Me.DoctordBindingSource
        Me.ComboBox1.DisplayMember = "fname"
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(710, 155)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(251, 24)
        Me.ComboBox1.TabIndex = 76
        Me.ComboBox1.ValueMember = "sname"
        '
        'DoctordBindingSource
        '
        Me.DoctordBindingSource.DataMember = "Doctor_d"
        Me.DoctordBindingSource.DataSource = Me.HmsDataSet1
        '
        'HmsDataSet1
        '
        Me.HmsDataSet1.DataSetName = "hmsDataSet1"
        Me.HmsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'HmsDataSetBindingSource
        '
        Me.HmsDataSetBindingSource.DataSource = Me.HmsDataSet
        Me.HmsDataSetBindingSource.Position = 0
        '
        'HmsDataSet
        '
        Me.HmsDataSet.DataSetName = "hmsDataSet"
        Me.HmsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(583, 213)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 17)
        Me.Label5.TabIndex = 78
        Me.Label5.Text = "DATE"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(710, 318)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(251, 22)
        Me.DateTimePicker2.TabIndex = 79
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(334, 627)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(207, 70)
        Me.Button1.TabIndex = 82
        Me.Button1.Text = "SAVE"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(515, 627)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(204, 70)
        Me.Button8.TabIndex = 81
        Me.Button8.Text = "WELCOME"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(707, 627)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(204, 70)
        Me.Button7.TabIndex = 80
        Me.Button7.Text = "CLOSE"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(583, 263)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 17)
        Me.Label6.TabIndex = 84
        Me.Label6.Text = "GENDER"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(710, 257)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(251, 22)
        Me.TextBox4.TabIndex = 85
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Lucida Handwriting", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(330, 42)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(298, 24)
        Me.Label7.TabIndex = 86
        Me.Label7.Text = "APPOINTMENT BOOKINGS"
        '
        'Doctor_dTableAdapter
        '
        Me.Doctor_dTableAdapter.ClearBeforeFill = True
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(710, 213)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(251, 22)
        Me.TextBox5.TabIndex = 87
        '
        'BOOK_APPOINTMENT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.BackgroundImage = Global.Hospital_Management_System.My.Resources.Resources.Become_a_Medical_Doctor_in_Germany
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1166, 709)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.avail_view)
        Me.Controls.Add(Me.Label8)
        Me.Name = "BOOK_APPOINTMENT"
        Me.Text = "BOOK_APPOINTMENT"
        CType(Me.DoctordBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HmsDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HmsDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HmsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents avail_view As System.Windows.Forms.ListView
    Friend WithEvents fname As System.Windows.Forms.ColumnHeader
    Friend WithEvents avail As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents HmsDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents HmsDataSet As Hospital_Management_System.hmsDataSet
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents HmsDataSet1 As Hospital_Management_System.hmsDataSet1
    Friend WithEvents DoctordBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Doctor_dTableAdapter As Hospital_Management_System.hmsDataSet1TableAdapters.Doctor_dTableAdapter
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
End Class

﻿Imports System.IO
Imports System.Data.SqlClient

Public Class STAFF_DETAILS
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim comstring As String
    Dim dataset As New DataSet

    Private Sub STAFF_DETAILS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=DESKTOP-9MTGMII\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()
        Else
            MsgBox("System Ready", MsgBoxStyle.Information)
        End If
        load_info()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim tbl_staff As New DataTable
        Dim i As Integer
        With obj_com
            .CommandText = "Select * From staff_details where id=" & TextBox1.Text
            .Connection = obj_conc
        End With
        With obj_adapter
            .SelectCommand = obj_com
            .Fill(dataset, "tbl_staff")
        End With
        info_view.Items.Clear() 'Avoids saving duplicate data through the text boxes
        For i = 0 To tbl_staff.Rows.Count - 1
            With info_view
                .Items.Add(tbl_staff.Rows(i)("id"))
                With .Items(.Items.Count - 1).SubItems
                    .Add(tbl_staff.Rows(i)("fname"))
                    .Add(tbl_staff.Rows(i)("sname"))
                    .Add(tbl_staff.Rows(i)("DOB"))
                    .Add(tbl_staff.Rows(i)("Emp_type"))
                    .Add(tbl_staff.Rows(i)("gender"))
                    .Add(tbl_staff.Rows(i)("salary"))
                    .Add(tbl_staff.Rows(i)("Postal_Ad"))
                    .Add(tbl_staff.Rows(i)("Email"))
                    .Add(tbl_staff.Rows(i)("Physical_Ad"))
                    .Add(tbl_staff.Rows(i)("Contact_No"))
                    .Add(tbl_staff.Rows(i)("Leave"))
                    .Add(tbl_staff.Rows(i)("Reg_Date"))
                End With
            End With
        Next
    End Sub

    Sub load_info()
        Dim tbl_staff As New DataTable
        Dim i As Integer
        With obj_com
            .CommandText = "Select * From staff_details"
            .Connection = obj_conc
        End With
        With obj_adapter
            .SelectCommand = obj_com
            .Fill(dataset, "tbl_staff")
        End With
        info_view.Items.Clear() 'Avoids saving duplicate data through the text boxes
        For i = 0 To tbl_staff.Rows.Count - 1
            With info_view
                .Items.Add(tbl_staff.Rows(i)("id"))
                With .Items(.Items.Count - 1).SubItems
                    .Add(tbl_staff.Rows(i)("fname"))
                    .Add(tbl_staff.Rows(i)("sname"))
                    .Add(tbl_staff.Rows(i)("DOB"))
                    .Add(tbl_staff.Rows(i)("Emp_type"))
                    .Add(tbl_staff.Rows(i)("gender"))
                    .Add(tbl_staff.Rows(i)("salary"))
                    .Add(tbl_staff.Rows(i)("Postal_Ad"))
                    .Add(tbl_staff.Rows(i)("Email"))
                    .Add(tbl_staff.Rows(i)("Physical_Ad"))
                    .Add(tbl_staff.Rows(i)("Contact_No"))
                    .Add(tbl_staff.Rows(i)("Contact2"))
                    .Add(tbl_staff.Rows(i)("Leave"))
                    .Add(tbl_staff.Rows(i)("Reg_Date"))
                End With
            End With
        Next
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        REGISTRATION.Show()
        Me.Hide()

    End Sub

    
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Close()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        VIEW_PATIENT_MED_REC.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LEAVE_APPLICATION.Show()
        Me.Hide()
    End Sub
End Class
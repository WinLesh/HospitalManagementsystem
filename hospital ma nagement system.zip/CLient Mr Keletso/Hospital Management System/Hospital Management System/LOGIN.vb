﻿Imports System
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Public Class LOGIN
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim dataset As New DataSet
    Public myreader As SqlDataReader

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub LOGIN_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=.\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()

        End If

        Label4.Visible = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
       
        login()
        'If ComboBox1.Text = "Administrator" Then
        '    STAFF_DETAILS.Show()
        '    Me.Hide()

        'Else
        '    If ComboBox1.Text = "DOCTOR" Then
        '        STAFF_DETAILS.Show()
        '        Me.Hide()

        '    Else
        '        If ComboBox1.Text = "Receptionist" Then
        '            RECEPTIONIST_VIEW.Show()
        '            Me.Hide()

        '        End If
        '    End If
        'End If

    End Sub

    Sub log()
        ' Dim cmd As New Data.SqlClient.SqlCommand(querystring, obj_conc)
        obj_com.CommandText = "Select * From slogin Where username = '" & TextBox1.Text & "';"
        obj_com.Connection = obj_conc
        obj_adapter.SelectCommand = obj_com
        obj_adapter.Fill(dataset, "slogin")

        'myreader = obj_com.ExecuteReader()
        'If myreader.Read Then
        '    Label4.Text = myreader("Emp_Type")

        '  End If

        


    End Sub
    'Sub load_details()
    '    Dim querystring As String = "SELECT * FROM staff_details WHERE id ='" & TextBox10.Text & "'"
    '    Dim cmd As New Data.SqlClient.SqlCommand(querystring, obj_conc)
    '    ' Dim tbl_enq As New DataTable

    '    myreader = cmd.ExecuteReader()
    '    If myreader.Read Then
    '        TextBox1.Text = myreader("id")
    '        TextBox2.Text = myreader("fname")
    '        TextBox3.Text = myreader("sname")
    '        TextBox11.Text = myreader("DOB")
    '        TextBox12.Text = myreader("Emp_Type")
    '        TextBox13.Text = myreader("Gender")
    '        TextBox14.Text = myreader("salary")
    '        TextBox4.Text = myreader("Physical_Ad")
    '        TextBox5.Text = myreader("Email")
    '        TextBox6.Text = myreader("Physical_Ad")
    '        TextBox7.Text = myreader("Contact_No")
    '        TextBox8.Text = myreader("Contact2")
    '        TextBox9.Text = myreader("Leave")
    '        TextBox15.Text = myreader("Reg_Date")

    '        ' MsgBox("Success")
    '        ' btn_proceed.Enabled = True
    '        'btn_save.Enabled = False
    '    Else
    '        MsgBox("Sorry an Error occured in attemting to read the data", MsgBoxStyle.Exclamation)
    '    End If
    'End Sub
    Sub login()
        If TextBox1.Text <> "" And TextBox2.Text <> "" Then
            ' Dim user_em As String
            Dim queryStr As String = "SELECT * FROM slogin WHERE username='" & TextBox1.Text & "'"
            Dim cmd As New SqlCommand(queryStr, obj_conc)
            Dim myreader As SqlDataReader = cmd.ExecuteReader
            'Dim usertypechecker As String
            If myreader.Read Then
                'user_em = TextBox1.Text
                ' If myreader(0).ToString = TextBox1.Text Then
                ' Session("UserID_cus") = TextBox1.Text
                ' Session("IsloggedIn") = True
                ' Session("UserType") = myreader(3).ToString
                'Response.Redirect("customer_pages/client.aspx")

                If ComboBox1.Text = "Administrator" Then
                    ' Response.Redirect("Client.aspx")
                    STAFF_DETAILS.Show()
                    Me.Hide()

                Else
                    If ComboBox1.Text = "HR" Then
                        ' Response.Redirect("Manager.aspx")
                        STAFF_DETAILS.Show()
                        Me.Hide()

                    Else
                        If ComboBox1.Text = "Doctor" Then
                            ' Response.Redirect("DataSpecialist.aspx")
                            doctor_view.Show()
                            Me.Hide()
                        Else
                            If ComboBox1.Text = "Receptionist" Then
                                RECEPTIONIST_VIEW.Show()
                                Me.Hide()

                            Else
                                If ComboBox1.Text = "Pharmacist" Then

                                End If
                                ' Response.Redirect("InspectingOfficer.aspx")
                            End If
                        End If
                    End If


                    ''  Else
                    'MsgBox("Error, Please check your details")
                End If
            End If
        End If
        ' End If

    End Sub
End Class
﻿Imports System.IO
Imports System.Data.SqlClient

Public Class DOCTOR_STATUS
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim dataset As New DataSet

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.Text <> "" And ComboBox2.Text <> "" Then

            With obj_com
                .Connection = obj_conc

                .CommandText = "INSERT INTO avail (fname, Doc_Status) VALUES ('" _
                & ComboBox1.Text & "','" & ComboBox2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Request recorded successfully", MsgBoxStyle.Information)
                ' btn_proceed.Enabled = True
            End With
        Else
            If ComboBox1.Text = "" Or ComboBox2.Text = "" Then
                MsgBox("Select Doctor status")
            End If
        End If
    End Sub

    Private Sub DOCTOR_STATUS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=DESKTOP-9MTGMII\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()

        End If
    End Sub
End Class
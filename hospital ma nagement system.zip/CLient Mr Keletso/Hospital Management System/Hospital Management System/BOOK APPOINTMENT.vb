﻿Imports System.IO
Imports System.Data.SqlClient

Public Class BOOK_APPOINTMENT
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim comstring As String
    Dim dataset As New DataSet

    Private Sub BOOK_APPOINTMENT_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HmsDataSet1.Doctor_d' table. You can move, or remove it, as needed.
        Me.Doctor_dTableAdapter.Fill(Me.HmsDataSet1.Doctor_d)

        TextBox1.Text = PATIENT_REGISTRATION.TextBox1.Text
        TextBox2.Text = PATIENT_REGISTRATION.TextBox2.Text
        TextBox3.Text = PATIENT_REGISTRATION.TextBox3.Text
        TextBox4.Text = PATIENT_REGISTRATION.ComboBox2.Text
        TextBox5.Text = PATIENT_REGISTRATION.DateTimePicker1.Text
        '  PATIENT_REGISTRATION.TextBox3.Text = TextBox3.Text

        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=DESKTOP-9MTGMII\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()

        End If
    End Sub

    Sub load_info()
        Dim tbl_doc As New DataTable
        Dim i As Integer
        With obj_com
            .CommandText = "Select * From avail"
            .Connection = obj_conc
        End With
        With obj_adapter
            .SelectCommand = obj_com
            .Fill(dataset, "tbl_doc")
        End With
        avail_view.Items.Clear() 'Avoids saving duplicate data through the text boxes
        For i = 0 To tbl_doc.Rows.Count - 1
            With avail_view
                .Items.Add(tbl_doc.Rows(i)("id"))
                With .Items(.Items.Count - 1).SubItems
                    .Add(tbl_doc.Rows(i)("fname"))
                    
                End With
            End With
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text <> "" And TextBox2.Text <> "" And ComboBox1.Text <> "" And TextBox3.Text <> "" And TextBox4.Text <> "" Then

            With obj_com
                .Connection = obj_conc

                .CommandText = "INSERT INTO appointments (id, fname, sname, doctor, ap_date, gender, Reg_Date) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox1.Text & "','" & TextBox5.Text & "','" & TextBox4.Text & "','" & DateTimePicker2.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Request recorded successfully", MsgBoxStyle.Information)
                ' btn_proceed.Enabled = True
            End With
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox1.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
                MsgBox("fill in all details", MsgBoxStyle.Information)
            End If
            ' obj_conc.Close()
        End If

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        WELCOME.Show()
        Me.Hide()

    End Sub
End Class
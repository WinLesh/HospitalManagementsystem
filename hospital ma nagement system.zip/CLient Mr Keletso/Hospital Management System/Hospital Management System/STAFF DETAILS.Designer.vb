﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class STAFF_DETAILS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.info_view = New System.Windows.Forms.ListView()
        Me.id = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.fname = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.sname = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.DOB = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Emp_type = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.gender = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.salary = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Postal_Ad = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Email = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Physical_Ad = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Contact_No = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Contact2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Leave = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Reg_Date = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'info_view
        '
        Me.info_view.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.id, Me.fname, Me.sname, Me.DOB, Me.Emp_type, Me.gender, Me.salary, Me.Postal_Ad, Me.Email, Me.Physical_Ad, Me.Contact_No, Me.Contact2, Me.Leave, Me.Reg_Date})
        Me.info_view.GridLines = True
        Me.info_view.Location = New System.Drawing.Point(12, 145)
        Me.info_view.Name = "info_view"
        Me.info_view.Size = New System.Drawing.Size(1052, 447)
        Me.info_view.TabIndex = 0
        Me.info_view.UseCompatibleStateImageBehavior = False
        Me.info_view.View = System.Windows.Forms.View.Details
        '
        'id
        '
        Me.id.Text = "ID "
        '
        'fname
        '
        Me.fname.Text = "FIRSTNAME"
        Me.fname.Width = 104
        '
        'sname
        '
        Me.sname.Text = "SURNAME"
        Me.sname.Width = 111
        '
        'DOB
        '
        Me.DOB.Text = "DOB"
        Me.DOB.Width = 97
        '
        'Emp_type
        '
        Me.Emp_type.Text = "STAFF TYPE"
        Me.Emp_type.Width = 117
        '
        'gender
        '
        Me.gender.Text = "GENDER"
        Me.gender.Width = 83
        '
        'salary
        '
        Me.salary.Text = "SALARY"
        Me.salary.Width = 100
        '
        'Postal_Ad
        '
        Me.Postal_Ad.Text = "POSTAL ADDRESS"
        Me.Postal_Ad.Width = 105
        '
        'Email
        '
        Me.Email.Text = "EMAIL"
        Me.Email.Width = 79
        '
        'Physical_Ad
        '
        Me.Physical_Ad.Text = "PHYSICAL ADDRESS"
        Me.Physical_Ad.Width = 113
        '
        'Contact_No
        '
        Me.Contact_No.Text = "CONTACT NO"
        Me.Contact_No.Width = 112
        '
        'Contact2
        '
        Me.Contact2.DisplayIndex = 12
        Me.Contact2.Text = "Contact No 2"
        '
        'Leave
        '
        Me.Leave.DisplayIndex = 13
        Me.Leave.Text = "Leave Days"
        '
        'Reg_Date
        '
        Me.Reg_Date.DisplayIndex = 11
        Me.Reg_Date.Text = "DATE REISTERED"
        Me.Reg_Date.Width = 143
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(55, 69)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(243, 22)
        Me.TextBox1.TabIndex = 1
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Hospital_Management_System.My.Resources.Resources.search2
        Me.PictureBox1.Location = New System.Drawing.Point(321, 52)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 63)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(1070, 259)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(250, 73)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "LEAVE APPLICATION"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(1070, 328)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(250, 63)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "EDIT"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(1070, 385)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(250, 65)
        Me.Button3.TabIndex = 5
        Me.Button3.Text = "DELETE"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(1070, 447)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(250, 60)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "UPDATE"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(1070, 539)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(250, 53)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "CLOSE"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(1070, 202)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(250, 62)
        Me.Button6.TabIndex = 8
        Me.Button6.Text = "REGISTER STAFF MEMBER"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(1070, 145)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(250, 64)
        Me.Button7.TabIndex = 9
        Me.Button7.Text = "VIEW REGISTERED PATIENTS"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'STAFF_DETAILS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1350, 624)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.info_view)
        Me.Name = "STAFF_DETAILS"
        Me.Text = "STAFF_DETAILS"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents info_view As System.Windows.Forms.ListView
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents id As System.Windows.Forms.ColumnHeader
    Friend WithEvents fname As System.Windows.Forms.ColumnHeader
    Friend WithEvents sname As System.Windows.Forms.ColumnHeader
    Friend WithEvents DOB As System.Windows.Forms.ColumnHeader
    Friend WithEvents Emp_type As System.Windows.Forms.ColumnHeader
    Friend WithEvents gender As System.Windows.Forms.ColumnHeader
    Friend WithEvents salary As System.Windows.Forms.ColumnHeader
    Friend WithEvents Postal_Ad As System.Windows.Forms.ColumnHeader
    Friend WithEvents Email As System.Windows.Forms.ColumnHeader
    Friend WithEvents Physical_Ad As System.Windows.Forms.ColumnHeader
    Friend WithEvents Contact_No As System.Windows.Forms.ColumnHeader
    Friend WithEvents Reg_Date As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Contact2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Leave As System.Windows.Forms.ColumnHeader
End Class

create database hms

create table slogin(
username varchar(50),
password_ varchar(50),
Emp_type varchar(50)
);


select * from slogin
select * from doctor_d

insert into slogin values ('try@gmail.com','12345678','Administrator')

create table staff_details(
id varchar(20),
fname varchar(50),
sname varchar(50),
DOB varchar(50),
Emp_type varchar(50),
gender varchar(6),
salary varchar(20),
Postal_Ad varchar(50),
Email varchar(20),
Physical_Ad varchar(50),
Contact_No varchar(20),
Contact2 varchar(20),
Leave varchar(20),
Reg_Date varchar(50),
primary key (id)
);

select * from staff_details

select * from admin


select * from admin
select * from slogin


create table Admin(
id varchar(20),
fname varchar(50),
sname varchar(50),
DOB varchar(50),
Emp_type varchar(50),
gender varchar(6),
salary varchar(20),
Postal_Ad varchar(50),
Email varchar(20),
Physical_Ad varchar(50),
Contact_No varchar(20),
Contact2 varchar(20),
Leave varchar(20),
Reg_Date varchar(50),
primary key (id)
);


create table Doctor_d(
id varchar(20),
fname varchar(50),
sname varchar(50),
DOB varchar(50),
Emp_type varchar(50),
gender varchar(6),
salary varchar(20),
Postal_Ad varchar(50),
Email varchar(20),
Physical_Ad varchar(50),
Contact_No varchar(20),
Contact2 varchar(20),
Leave varchar(20),
Reg_Date varchar(50),
primary key (id)
);


create table HR(
id varchar(20),
fname varchar(50),
sname varchar(50),
DOB varchar(50),
Emp_type varchar(50),
gender varchar(6),
salary varchar(20),
Postal_Ad varchar(50),
Email varchar(20),
Physical_Ad varchar(50),
Contact_No varchar(20),
Contact2 varchar(20),
Leave varchar(20),
Reg_Date varchar(50),
primary key (id)
);


create table Pharmacist_d(
id varchar(20),
fname varchar(50),
sname varchar(50),
DOB varchar(50),
Emp_type varchar(50),
gender varchar(6),
salary varchar(20),
Postal_Ad varchar(50),
Email varchar(20),
Physical_Ad varchar(50),
Contact_No varchar(20),
Contact2 varchar(20),
Leave varchar(20),
Reg_Date varchar(50),
primary key (id)
);


create table Recept(
id varchar(20),
fname varchar(50),
sname varchar(50),
DOB varchar(20),
Emp_type varchar(50),
gender varchar(6),
salary varchar(20),
Postal_Ad varchar(50),
Email varchar(20),
Physical_Ad varchar(50),
Contact_No varchar(20),
Contact2 varchar(20),
Leave varchar(20),
Reg_Date varchar(20),
primary key (id)
);


create table a_appoint (
id varchar(20),
fname varchar(50),
sname varchar(50),
doctor varchar(50),
Ap_Date varchar(50),
gender varchar(50),
Reg_Date varchar(50),
Ap_Status varchar(50),
primary key (id)
);

create table appointments (
id varchar(20),
fname varchar(50),
sname varchar(50),
doctor varchar(30),
ap_date varchar(50),
gender varchar(6),
Reg_Date varchar(50),
primary key (id)
);

insert into appointments values ('783478','fry','fry','let','37467836','male','836487')
select * from appointments
drop table appointments

create table avail(
fname varchar(20),
Doc_Status varchar(20),
);

create table leave_ap (
id varchar (20),
fname varchar(50),
staff_type varchar(50),
days_left varchar(10),
days_taken varchar(10),
primary key (id)
)

create table patient (
id varchar(20),
fname varchar(50),
sname varchar(50),
DOB varchar(50),
POB varchar(50),
gender varchar(6),
Reg_Date varchar(50),
primary key (id)
);



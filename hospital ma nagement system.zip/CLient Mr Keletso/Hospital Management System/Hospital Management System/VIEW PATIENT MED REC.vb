﻿Imports System.IO
Imports System.Data.SqlClient

Public Class VIEW_PATIENT_MED_REC
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim comstring As String
    Dim dataset As New DataSet

    Private Sub VIEW_PATIENT_MED_REC_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=DESKTOP-9MTGMII\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()
       
        End If
        load_info()
    End Sub

    Sub load_info()
        Dim tbl_patient As New DataTable
        Dim i As Integer
        With obj_com
            .CommandText = "Select * From patient"
            .Connection = obj_conc
        End With
        With obj_adapter
            .SelectCommand = obj_com
            .Fill(dataset, "tbl_patient")
        End With
        patient_view.Items.Clear() 'Avoids saving duplicate data through the text boxes
        For i = 0 To tbl_patient.Rows.Count - 1
            With patient_view
                .Items.Add(tbl_patient.Rows(i)("id"))
                With .Items(.Items.Count - 1).SubItems
                    .Add(tbl_patient.Rows(i)("fname"))
                    .Add(tbl_patient.Rows(i)("sname"))
                    .Add(tbl_patient.Rows(i)("DOB"))
                    .Add(tbl_patient.Rows(i)("POB"))
                    .Add(tbl_patient.Rows(i)("gender"))
                    .Add(tbl_patient.Rows(i)("Reg_Date"))
                End With
            End With
        Next
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim tbl_patient As New DataTable
        Dim i As Integer
        With obj_com
            .CommandText = "Select * From patient where id=" & TextBox1.Text
            .Connection = obj_conc
        End With
        With obj_adapter
            .SelectCommand = obj_com
            .Fill(dataset, "tbl_patient")
        End With
        patient_view.Items.Clear() 'Avoids saving duplicate data through the text boxes
        For i = 0 To tbl_patient.Rows.Count - 1
            With patient_view
                .Items.Add(tbl_patient.Rows(i)("id"))
                With .Items(.Items.Count - 1).SubItems
                    .Add(tbl_patient.Rows(i)("fname"))
                    .Add(tbl_patient.Rows(i)("sname"))
                    .Add(tbl_patient.Rows(i)("DOB"))
                    .Add(tbl_patient.Rows(i)("POB"))
                    .Add(tbl_patient.Rows(i)("gender"))
                    .Add(tbl_patient.Rows(i)("Reg_Date"))
                End With
            End With
        Next
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
        STAFF_DETAILS.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        WELCOME.Show()
        Me.Hide()
    End Sub

  
End Class
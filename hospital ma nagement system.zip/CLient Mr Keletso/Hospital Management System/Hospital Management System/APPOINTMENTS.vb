﻿Public Class APPOINTMENTS
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim dataset As New DataSet
    Friend ID As String
    Friend Firstname As String
    Friend Surname As String
    Friend doctor As String
    Friend Ap_Date As String
    Friend gender As String
    Friend registered_date As String


    Private Sub APPOINTMENTS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=DESKTOP-9MTGMII\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()

        End If
        TextBox1.Text = ID
        TextBox2.Text = Firstname
        TextBox3.Text = Surname
        TextBox4.Text = doctor
        TextBox5.Text = Ap_Date
        TextBox6.Text = gender
        TextBox7.Text = registered_date
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PATIENTS_APPOINTMENTS.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text <> "" And TextBox2.Text <> "" And TextBox4.Text <> "" And TextBox3.Text <> "" Then

            With obj_com
                .Connection = obj_conc

                .CommandText = "INSERT INTO a_appoint (id, fname, sname, doctor, Ap_Date, gender, Reg_Date, Ap_Status) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & ComboBox1.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Request recorded successfully", MsgBoxStyle.Information)
                ' btn_proceed.Enabled = True
            End With
        Else
            If ComboBox1.Text = "" Then
                MsgBox("Please update appointment status", MsgBoxStyle.Information)
            End If
            ' obj_conc.Close()
        End If
    End Sub
End Class
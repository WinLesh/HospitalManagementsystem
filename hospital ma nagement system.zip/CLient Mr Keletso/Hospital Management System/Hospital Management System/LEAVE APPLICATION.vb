﻿Imports System.IO
Imports System.Data.SqlClient

Public Class LEAVE_APPLICATION
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
      Dim comstring As String
    Public myreader As SqlDataReader

    Private Sub LEAVE_APPLICATION_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=.\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()

            ' MsgBox("System Ready", MsgBoxStyle.Information)
        End If
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        save_details()
        If ComboBox1.Text = "Doctor" Then
            DOCTOR_STATUS.Show()
            Me.Hide()
        Else
            STAFF_DETAILS.ShowDialog()
            Me.Hide()
        End If
    End Sub

    Sub save_details()
        If TextBox1.Text <> "" And TextBox2.Text <> "" And ComboBox1.Text <> "" And TextBox3.Text <> "" And TextBox4.Text <> "" And ComboBox1.Text <> "" Then

            With obj_com
                .Connection = obj_conc

                .CommandText = "INSERT INTO leave_ap (id, fname, staff_type, days_left, days_taken) VALUES ('" _
                & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "')"
                .ExecuteNonQuery()
                MsgBox("Request recorded successfully", MsgBoxStyle.Information)
                '  btn_proceed.Enabled = True
            End With
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox1.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
                MsgBox("fill in all details", MsgBoxStyle.Information)
            End If
            ' obj_conc.Close()
        End If
    End Sub

    'Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
    '    Dim querystring As String = "SELECT * FROM staff_details WHERE id ='" & TextBox5.Text & "'"
    '    Dim cmd As New Data.SqlClient.SqlCommand(querystring, obj_conc)
    '    ' Dim tbl_enq As New DataTable

    '    myreader = cmd.ExecuteReader()
    '    If myreader.Read Then
    '        TextBox1.Text = myreader("id")
    '        TextBox2.Text = myreader("fname" + " " + "sname")
    '        ComboBox1.Text = ("Emp_Type")
    '        '  DateTimePicker1.Text = ("DOB")
    '        TextBox3.Text = ("leave")
    '        '  ComboBox2.Text = myreader("gender")
    '        '  DateTimePicker2.Text = myreader("Reg_Date")

    '        MsgBox("Success")
    '        ' btn_proceed.Enabled = True
    '        ' btn_save.Enabled = False
    '    Else
    '        MsgBox("Sorry an Error occured in attemting to read the data", MsgBoxStyle.Exclamation)
    '    End If
    'End Sub
End Class
﻿Imports System.IO
Imports System.Data.SqlClient


Public Class PATIENTS_APPOINTMENTS
    Dim obj_conc As New SqlClient.SqlConnection 'create a variable that will be used to connect to the database
    Dim obj_com As New SqlClient.SqlCommand
    Dim obj_adapter As New SqlClient.SqlDataAdapter
    Dim comstring As String
    Dim dataset As New DataSet
    Public myreader As SqlDataReader

    Public index As String

   
    'Private Sub patient_View_MouseClick(sender As Object, e As MouseEventArgs)
    '    index = patient_view.SelectedItems(0).Text
    'End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        WELCOME.Show()
        Me.Hide()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
        STAFF_DETAILS.ShowDialog()

    End Sub

    Private Sub PATIENTS_APPOINTMENTS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If obj_conc.State = ConnectionState.Closed Then
            obj_conc.ConnectionString = ("Data Source=DESKTOP-9MTGMII\SQLEXPRESS;Initial Catalog=hms;Integrated Security=True")
            obj_com.Connection = obj_conc
            obj_conc.Open()
        
        End If

        'load_info()
        'Dim tbl_patient As New DataTable
        'Dim i As Integer
        'With obj_com
        '    .CommandText = "Select * From appointments"
        '    .Connection = obj_conc
        'End With
        'With obj_adapter
        '    .SelectCommand = obj_com
        '    .Fill(dataset, "tbl_patient")
        'End With
        'patient_view.Items.Clear() 'Avoids saving duplicate data through the text boxes
        'For i = 0 To tbl_patient.Rows.Count - 1
        '    With patient_view
        '        .Items.Add(tbl_patient.Rows(i)("id"))
        '        With .Items(.Items.Count - 1).SubItems
        '            .Add(tbl_patient.Rows(i)("fname"))
        '            .Add(tbl_patient.Rows(i)("sname"))
        '            .Add(tbl_patient.Rows(i)("doctor"))
        '            .Add(tbl_patient.Rows(i)("ap_date"))
        '            .Add(tbl_patient.Rows(i)("gender"))
        '            .Add(tbl_patient.Rows(i)("Reg_Date"))
        '        End With
        '    End With
        'Next
    End Sub

    'Sub load_info()
    '    Dim tbl_patient As New DataTable
    '    Dim i As Integer
    '    With obj_com
    '        .CommandText = "Select * From appointments"
    '        .Connection = obj_conc
    '    End With
    '    With obj_adapter
    '        .SelectCommand = obj_com
    '        .Fill(dataset, "tbl_patient")
    '    End With
    '    patient_view.Items.Clear() 'Avoids saving duplicate data through the text boxes
    '    For i = 0 To tbl_patient.Rows.Count - 1
    '        With patient_view
    '            .Items.Add(tbl_patient.Rows(i)("id"))
    '            With .Items(.Items.Count - 1).SubItems
    '                .Add(tbl_patient.Rows(i)("fname"))
    '                .Add(tbl_patient.Rows(i)("sname"))
    '                .Add(tbl_patient.Rows(i)("doctor"))
    '                .Add(tbl_patient.Rows(i)("Ap_Date"))
    '                .Add(tbl_patient.Rows(i)("gender"))
    '                .Add(tbl_patient.Rows(i)("Reg_Date"))
    '            End With
    '        End With
    '    Next
    'End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        'If index = Nothing Then
        '    MsgBox("Please select record to attend", MsgBoxStyle.Information)
        'Else
        If index <> "" Then
            Dim sqlcom As String = "Select * From appointments where id='" & TextBox1.Text & "'"
            Dim obj_com As New SqlClient.SqlCommand
            Dim obj_adapter As New SqlClient.SqlDataAdapter
            Dim tbl_appoint As New DataTable

            With obj_com
                .CommandText = sqlcom
                .Connection = obj_conc
            End With
            With obj_adapter 'used with method to avoid rewritting adapter object and defining its aspects 
                .SelectCommand = obj_com
                '  .Fill(tbl_appoint)
            End With

            APPOINTMENTS.ID = TextBox1.Text
            APPOINTMENTS.Firstname = TextBox2.Text
            APPOINTMENTS.Surname = TextBox3.Text
            APPOINTMENTS.doctor = TextBox4.Text
            APPOINTMENTS.Ap_Date = TextBox5.Text
            APPOINTMENTS.gender = TextBox7.Text
            APPOINTMENTS.registered_date = TextBox6.Text
            APPOINTMENTS.ShowDialog()
        End If
        ' End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim querystring As String = "SELECT * FROM appointments WHERE id ='" & TextBox8.Text & "'"
        Dim cmd As New Data.SqlClient.SqlCommand(querystring, obj_conc)
        ' Dim tbl_enq As New DataTable

        myreader = cmd.ExecuteReader()
        If myreader.Read Then
            TextBox1.Text = myreader("id")
            TextBox2.Text = myreader("fname")
            TextBox3.Text = ("sname")
            TextBox4.Text = ("doctor")
            TextBox5.Text = ("ap_date")
            TextBox7.Text = ("gender")
            'ComboBox2.Text = myreader("gender")
            TextBox6.Text = myreader("Reg_Date")

            ' MsgBox("Success")
            'btn_proceed.Enabled = True
            'btn_save.Enabled = False
        Else
            MsgBox("Sorry an Error occured in attemting to read the data", MsgBoxStyle.Exclamation)
        End If
    End Sub
End Class
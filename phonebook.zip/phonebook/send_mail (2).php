<?php
	// Add db connection library
	require_once("db_connect.php");
	session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
     <head>
         <title> send mail</title>
	         <meta name= "Keywords"contents= "mail">
	         <meta name= "description" contents= "send mail">
	         <meta name= "author" contents= "L.W.Seshabo">	
   
   <!-- the external style sheet here-->
   <link href="styles/main.css" rel="stylesheet" type="text/css" />
   <style type="text/css">
 body {background-image :url('images/images77.jpg'); background-size: 1750px;	  
	
  }
  </style>
 <!--content starts-->
     </head>
				<body>
		 
				
				
				
				
		 
							 <div id="banner"  style="position:center height:293px; width:500px; ">
							 <h1>University Of Botswana</h1>
							 <hr>
		</hr>

				 <img src="images/images.JPG"  alt="logo" height="150px" width="150px" />
							 
							 </div>
								 <div id="links"  align="right" style=" height:60px; width:500px; ">
								
								<h2><a href="index.php">LogOut</a> &#124;
	                            <a href="#">Help</a> </h2>
								
								  </div>

							 <div id="content" align="centre" style="  height:400px; width:500px;">

		   <form>
						 <fieldset>
						  
							 <legend>Search</legend>
							 
										 <label for="Name"> Name:</label><br /> 

											<input name = "name" type = "text" size = "25" maxlength = "20"/>
											<br/>
											<label for="subject" >Subject:</label><br />
											
											<input name = "ini" type = "text" maxlength="25" size="15"/>
											<br/>
											<label for = "name"> Email:</label> <br />
			                                <input value="" id = "name" name="name" size="35" maxlength="30" type="text" />
			                                <br />
											
											<label>Write mail:</label><br />
	                                         <textarea name = "About_you"  rows = "5" cols= "40" ">start your mail here</textarea>   <br />
		                                      
											  <label for = "name">To:</label><br /> 
			                                  <input value="" id = "name" name="name" size="35" maxlength="30" type="textbox" disabled="disabled" />
			                                   <br />
        		
											
											
											<input type="submit" value="Send" name="submit" /> 
											<input type="reset" value="cancel" />
											</div>
											 
                 </fieldset>
				 
	</form>
	 
	 
	 
	 
	 
	 
	 <!---content ends-->
	 <div id="footer"style="  width:500px; " >
Copyright &nbsp;&copy; Lesego seshabo</div

	 
	    </body>
</html>	 
	 
	 
	 
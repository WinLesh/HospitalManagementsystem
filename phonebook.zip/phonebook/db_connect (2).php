<?php

// For connecting to the database

function db_connect($db_name)
{
   $host_name = "10.0.19.74";
   $user_name = "root";
   $password = "";
   $db_link = mysql_connect($host_name, $user_name, $password)
      or die("Could not connect to $host_name");
   mysql_select_db($db_name) or die("Could not select database $db_name");
   return $db_link;
}
?>
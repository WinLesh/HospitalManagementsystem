<?php
	// database connection
	require_once("db_connect.php");
	session_start();
	
	if(isset($_SESSION['admin_uname']))
	{
		header("Location: staff.php");
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
     <head>
         <title> phone directory </title>
	         <meta name= "Keywords"contents= "Login">
	         <meta name= "description" contents= "Admin">
	         <meta name= "author" contents= "L.W.Seshabo">	
   
   <!-- the external style sheet here-->
   <script language="javascript" src="js/validate.js" type="text/javascript"></script>
   <link href="styles/main.css" rel="stylesheet" type="text/css" />
   <style type="text/css">
 body {background-image :url('images/images77.jpg'); background-size: 1750px;
  }
 </style>
<script>
	<!--
	function validateForm()
   {
    var x=document.forms["admin_login"]["username"].value;
    if (x==null || x=="")
    {
      alert("fill the username field ");
      return false;
    }
	
	var y=document.forms["admin_login"]["password"].value;
    if (y==null || y=="")
    {
      alert("fill the password field");
      return false;
    }
  }
  -->
  </script>


     </head>
				<body>
		 
		                     <div id="banner"  style="position:center height:293px; width:500px; ">
							 <h1>University Of Botswana</h1>
							 <hr>
		</hr>

							 <img src="images/images.JPG"  alt="logo" height="150px" width="150px" />
							 
							 </div>
								  <div id="links"  align="right" style=" height:60px; width:500px;">
								<a href="staff.php"></a> 
								
								
								  </div>

							 <div id="content" align="centre" style="  height:200px; width:500px;">

		   <form method = "post"  align="centre" method = "POST" action = "admin_login.php" onSubmit = "return validateForm()" name="admin_login" >
						 <fieldset>
						  
							 
							 
										 <label for="username"> username:</label><br /> 

											<input name = "username" type = "text" size = "25" maxlength = "20" <?php echo $username; ?>/>
											</br>
											<label for="password" >password:</label><br />
											
											<input name = "password" type = "password" maxlength="25" size="15" />
											</br>	
											
											<input type="submit" value="login" name="submit" /> 
											<input type="reset" value="clear" />
											</div>
											 
                 </fieldset>
				 
	</form>
		



			
	

	 
	 
	<?php
	require_once("includes/db_connect.php");
	//Connecting to the database
	
	$conn = mysql_connect("10.0.19.74","ses0317", "ses04317") or die ("Error connecting to MySQL");
	
	//selecting a database to use
	mysql_select_db("db_ses04317", $conn) or die ("Could not open database");
	
	//Aquiring the username and password from the log in form
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	//check if the user isn't logged in yet
	session_start();
	
	$err_message = " you are not logged in";
	$username = "";
	
	//check if user submitting login form
	if(isset($_POST['login']))
	{
		//log the user in
		$db_link = db_connect();
		$password = mysql_real_escape_string($_POST['password']);
		$username = mysql_real_escape_string($_POST['username']); 
		
		$sql = "SELECT password, username FROM csi315_dir_admins WHERE username='$username' AND password='$password'";
		$result = mysql_query($sql) or die( mysql_error() );
		$num_rows = mysql_num_rows($result); 
		
		if($num_rows != 0)
		{
			$row = mysql_fetch_assoc($result);
			
			$staff_id = $row['staff_id'];
			
			//add session variables
			$_SESSION['is_adm'] = 1;
			
			header('Location: staff.php');
				
		}
		else
		{
			$err_message = "You have entered the wrong username or password.";		
		}
		mysql_free_result($result);
		mysql_close($db_link);
		
	}
	else
	
	
		if(isset($_SESSION['s_id']))
		{
			//the user has logged in, redirect to profile page
			header('Location: staff.php');
		}
			mysql_close($conn);
		?> 
	 
	 
	 
	 
	 
	 
	 
	 
<div id="footer"style="  width:500px; " >
Copyright &nbsp;&copy; Lesego seshabo</div

	 
	    </body>
</html>	 
	 

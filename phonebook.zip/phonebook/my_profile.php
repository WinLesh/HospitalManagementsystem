<?php
	// database connection
	require_once("db_connect.php");
	session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
     <head>
         <title> my profile</title>
	         <meta name= "Keywords"contents= "staff">
	         <meta name= "description" contents= "admin">
	         <meta name= "author" contents= "L.W.Seshabo">	
   
   <!-- the external style sheet here-->
   <script language="javascript" src="js/validate.js" type="text/javascript"></script>
   <link href="styles/main.css" rel="stylesheet" type="text/css" />
   <style type="text/css">
 body {background-image :url('images/images77.jpg'); background-size: 1750px;	  
	
  }
  </style>
 


</style>
     </head>
				<body>
		 
				
				
				
				
		 
							 <div id="banner"  style="position:center height:293px; width:500px; ">
							 <h1>University Of Botswana</h1>
							 <hr>
		</hr>

							  <img src="images/images.JPG"  alt="logo" height="150px" width="150px" />
							 
							 </div>
								 <div id="links"  align="right" style=" height:60px; width:500px;">
								
								<h2><a href="index.php">LogOut</a> &#124;
	                            <a href="#">Help</a> </h2>
								
								  </div>

							 <div id="content" align="centre" style="  height:300px; width:500px;">

		   <form name = "frm3" action = "my_profile.php" method = "post" onSubmit = "return validateForm();" >
						 <fieldset>
						  
							 <legend>Search</legend>
							 
										 <label for="Name">Title:</label><br /> 

											<input name = "name" type = "text" size = "25" maxlength = "20"/>
											</br>
											<label for="Initials" >Initials:</label><br />
											
											<input name = "ini" type = "text" maxlength="25" size="15" />
											</br>	
											
											<label for="surname" >Surname:</label><br />
											
											<input name = "sr" type = "text" maxlength="25" size="15" />
											</br>
											
											<label for="department" >Department:</label><br />
											<input name = "dpt" type = "text" maxlength="25" size="15" />
											</br>
											
											<label for = "photo">Photo:</label> <br />
			                                <input name="photo" size = "30" type="file" />
			                                <br />
											
											
											<input type="submit" value="Update" name="submit" /> 
											<input type="reset" value="cancel" />
											</div>
											 
                 </fieldset>
				 
	</form>
	<div>
	<?php
				require_once 'phfunctions.php';

				session_start();

				if (!isset($_SESSION['user']))
				die("<br /><br />login to view");
		
				$passwordupd = $_POST['password_upd'];
				$formtitle = $_POST[title];
				
				echo $formtitle ;
				
				$formsurname = $_POST['surname'];
				$formemail = $_POST['email'];
			
				$formpassword = $_POST['password'];
				
				if(isset($formtitle) && isset($formsurname) && isset($formemail) && isset($formpassword) )
				{
					$con = mysql_connect("localhost", "mok00140", "mok00140")
						or die("no connection " . mysql_error());
						echo $formpassword ;
						print ("Connection Successful");
					
					mysql_select_db("dbmok00140_", $con);
					
					
					
					 $result = mysql_query( "UPDATE staff SET title = '$formtitle', surname = '$formsurname', email = '$formemail', password = '$formpassword' 
											WHERE password = '$passwordupd' " ) or die( mysql_error() ) ;
						
						
					if(!$result)
					{
						echo "no update";
					}
				mysql_close($con);
				}
				
			?>
		
		</div>	






	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
<div id="footer"style="  width:500px; " >
Copyright &nbsp;&copy; Lesego seshabo</div

	 
	    </body>
</html>	 
	 
	 
	 
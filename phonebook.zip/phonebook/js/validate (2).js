String.prototype.trim = function ()
{
	return this.replace(/^\s+/,'').replace(/\s+$/,'');
}

function ValidateEntry(frm)
{
	//check if the name field is empty
	var strUserName = frm.txtFullName.value;
	if (strUserName.trim() == "")
	{
		alert("Please enter your name");
		frm.txtFullName.focus();
		frm.txtFullName.style.backgroundColor = 'Pink';
		frm.txtFullName.style.borderColor = 'violet';
		return false;
	}
	//check if the ID field is empty
	var strStudentID = frm.txtID.value;
	if (strStudentID.trim() =="")
	{
	    alert("Please enter your student ID");
		frm.txtID.focus();
		frm.txtID.style.backgroundColor = 'Pink';
		frm.txtID.style.borderColor = 'violet';
		return false;
	}
	
	
	

	//check if the ID is numeric
	var strID = frm.txtID.value;
	if (strID != parseInt(strID))
	{
		alert("Please enter a valid ID");
		return false;
	}
	
	//check if gender was selected
	var strGender
	if(frm.rdoGender[0].checked==true){strGender = frm.rdoGender[0].value;}
	if(frm.rdoGender[1].checked==true){strGender = frm.rdoGender[1].value;}
	if(strGender != 'M' && strGender !='F')
	{
		alert("Please select your gender");
		return false;
	}
	
	
	//check if an email address was entered
	var strAddress=frm.email.value;
	if(strAddress.trim() == "")
	{
	    alert("Please enter the email address");
		frm.email.focus();
		frm.email.style.backgroundColor = 'Pink';
		frm.email.style.borderColor = 'violet';
		return false;
	}
	
	//check if a username was entered
	var strUser=frm.txtUsername.value;
	if(strUser.trim() == "")
	{
	    alert("Please enter your username" )
		frm.txtUsername.focus();
		frm.txtUsername.style.backgroundColor = 'Pink';
		frm.txtUsername.style.borderColor = 'violet';
		return false;
	}
	//check if a password was entered
	var strPassword=frm.txtPwd.value;
	if(strPassword.trim() == "")
	{
	    alert("Please enter your password")
		frm.txtPwd.focus();
		frm.txtPwd.style.backgroundColor = 'Pink';
		frm.txtPwd.style.borderColor = 'violet';
		return false;
	}
	//check if a password confirmation was entered
	var strConfirmPassword=frm.txtPwd2.value;
	if(strConfirmPassword.trim() == "")
	{
	    alert("confirm password")
		frm.txtPwd2.focus();
		frm.txtPwd2.style.backgroundColor = 'Pink';
		frm.txtPwd2.style.borderColor = 'violet';
		return false;
	}
	//check if the password and confirmation are the same
	
	var strConfirmPassword= frm.txtPwd2.value;
	var strPassword= frm.txtPwd.value;
	if (strPassword != strConfirmPassword)
	{
	    alert("Passwords does not match")
		return false;
	}
}


<?php
	// Add db connection library
	require_once("db_connect.php");
	session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
     <head>
         <title> Search</title>
	         <meta name= "Keywords"contents= "index">
	         <meta name= "description" contents= "Home Page">
	         <meta name= "author" contents= "L.W.Seshabo">	
   
   <!-- the external style sheet here-->
   <link href="styles/main.css" rel="stylesheet" type="text/css" />
   <style type="text/css">
 body {background-image :url('images/images77.jpg'); background-size: 1750px;	
  }

</style>
     </head>
				<body>
		 
				
				
				
				
		 
							 <div id="banner"  style="position:center height:293px; width:500px; ">
							 <h1>University Of Botswana</h1>
							 <hr>
		</hr>

				              <img src="images/images.JPG"  alt="logo" height="150px" width="150px" />
							 
							 </div>
								  <div id="links"  align="right" style=" height:60px; width:500px;">
								<a href="login.php">login</a> &#124
								<a href="#">Help</a>&#124
								<a href="search.php">Search</a>
								
								  </div>

							<div id="content" align="centre" style="  height:200px; width:500px;">

		   
						 <form action="search.php" name="searchform" 
		 method="post" align="center">
		
		<h2>Search</h2>	
			<fieldset>
			<legend></legend>
			
			<label for = "name">Name:</label> 
			<input value="" id = "name" name="name" size="35" maxlength="30" type="text" />
			<br/>
			<br/>
			
			<label for = " department">Department:</label>
			<select name="department" id = "department">
			    <option   value="0">Select a department...</option>
<optgroup label="BUSINESS"><option  value = "751">ACCOUNTING AND FINANCE</option>
<option  value = "750">FACULTY OFFICE - BUSINESS</option>
<option  value = "755">MANAGEMENT</option>
<option  value = "753">MARKETING</option>
<option  value = "756">TOURISM AND HOSPITALITY MGT.</option>
</optgroup><optgroup label="CENTRE FOR ACADEMIC DEVELOPMET"><option  value = "410">COMMUNICATION &amp; STUDY SKILLS</option>
<option  value = "522">DIRECTOR CAD</option>
<option  value = "500">PRE-ENTRY SCIENCE</option>
<option  value = "525">PROGRAMME REVIEW(CAD)</option>
</optgroup><optgroup label="CENTRE FOR CONTINUING ED."><option  value = "532">CCE-DIRECTORATE</option>
</optgroup><optgroup label="EDUCATION"><option  value = "104">ADULT EDUCATION</option>
<option  value = "105">EDUCATIONAL FOUNDATIONS</option>
<option  value = "106">EDUCATIONL TECHNOLOGY</option>
<option  value = "207">ENGLISH</option>
<option  value = "101">FACULTY OFFICE EDUCATION</option>
<option  value = "150">FAMILY AND CONSUMER SCIENCES</option>
<option  value = "156">GUIDANCE AND COUNS(SEE-833)</option>
<option  value = "155">PHYSICAL EDUCATION</option>
<option  value = "153">PRIMARY EDUCATION</option>
<option  value = "166">SCHOOL OF NURSING</option>
</optgroup><optgroup label="ENGINEERING AND TECHNOLOGY"><option  value = "608">ARCHITECTURE AND PLANNING</option>
<option  value = "606">C D P U</option>
<option  value = "604">CIVIL ENGINEERING</option>
<option  value = "601">FACULTY OFFICE FET</option>
<option  value = "605">INDUSTRIAL DESIGN AND TECHNOLO</option>
<option  value = "603">MECHANICAL ENGINEERING</option>
<option  value = "607">TECHNOLOGY AND EDUCATION STUDS</option>
</optgroup><optgroup label="HEALTH SCIENCES"><option  value = "424">DEP OF ENVIRONMENTAL HEALTH</option>
<option  value = "802">FACULTY OFFICE HEALTH SCIENCES</option>
</optgroup><optgroup label="HUMANITIES"><option  value = "206">AFRICAN LANGUAGES &amp; LITERATURE</option>
<option  value = "201">FACULTY OFFICE HUMANITIES</option>
<option  value = "210">FRENCH</option>
<option  value = "261">LIBRARY &amp; INFORMATION STUDIES</option>
<option  value = "211">MEDIA STUDIES</option>
<option  value = "209">THEOLOGY AND RELIGIOUS STUDIES</option>
<option  value = "213">VISUAL AND PERFORMING ARTS</option>
</optgroup><optgroup label="MEDICINE"><option  value = "801"> SCHOOL OF MEDICINE-DEAN'S OFF</option>
</optgroup><optgroup label="SCHOOL OF GRADUATE STUDIES"><option  value = "314">ACCOUNTANCY AND MANA(SEE-751)</option>
<option  value = "311">ECONOMICS</option>
<option  value = "419">ENVIRONMENTAL SCIENCE</option>
<option  value = "510">FACULTY OFFICE  GRADUATE STUDS</option>
<option  value = "208">HISTORY</option>
<option  value = "102">LANGUAGES &amp; SOCIAL SCIENCE ED.</option>
<option  value = "103">MATHEMATICS &amp;SCIENCE EDUCATION</option>
<option  value = "312">POLITICS &amp; ADMINISTRATIVE STUD</option>
<option  value = "372">SOCIAL WORK</option>
<option  value = "313">SOCIOLOGY</option>
<option  value = "315">STATISTICS</option>
</optgroup><optgroup label="SCIENCE"><option  value = "417">BIOLOGICAL SCIENCES</option>
<option  value = "418">CHEMISTRY</option>
<option  value = "422">COMPUTER SCIENCE</option>
<option  value = "401">FACULTY OFFICE SCIENCES</option>
<option  value = "460">GEOLOGY</option>
<option  value = "420">MATHEMATICS</option>
<option  value = "421">PHYSICS</option>
</optgroup><optgroup label="SOCIAL SCIENCES"><option  value = "301">FACULTY OFFICE SOCIAL SCIENCE</option>
<option  value = "367">LAW</option>
<option  value = "368">POPULATION STUDIES</option>
<option  value = "316">PSYCHOLOGY</option>
</optgroup>			
</select> 
<br/>
<br/>

	<input name="search" value="search" size="6" type="submit" />
		&nbsp; &nbsp; <input name="reset" value="Start over" size="10" type="reset" />	<br />
		</fieldset>
	</form>





	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
<div id="footer"style="  width:500px; " >
Copyright &nbsp;&copy; Lesego seshabo</div

	 
	    </body>
</html>	 
	 
	 
	 

<head>
<title>search</title>
</head>
<?php
$con = mysql_connect("localhost","mok00140","mok00140");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("db_mok00140", $con);
			
            $names = $_POST['username'];
		    $dpt = $_POST['derpartment']; 
			
          $result = mysql_query("SELECT * FROM staff");
		   
         while ($row = mysql_fetch_array($result)){
	        echo 'Name: '.$row['surname'];
	        echo '<br/> Department id: '.$row['department_id'];
	        echo '<br/> Phone Number: '.$row['phone'];
	        echo '<br/> Location: '.$row['office'];
			echo '<br/> Email: '.$row['email'];
	        echo '<br/><br/>';
			
	        }
			
			
			 mysql_close($con); 
?>  
</html>
<?php
	// database connection
	require_once("db_connect.php");
	session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
     <head>
         <title> phone directory </title>
	         <meta name= "Keywords"contents= "Login">
	         <meta name= "description" contents= "login">
	         <meta name= "author" contents= "L.W.Seshabo">	
   
   <!-- the external style sheet here-->
   	 <script language="javascript" src="js/validate.js" type="text/javascript"></script>
   <link href="styles/main.css" rel="stylesheet" type="text/css" />
     <style type="text/css">
 body {background-image :url('images/images77.jpg'); background-size: 1750px;  
	
  }	 
  </style>
  <script>
	<!--
	function validateForm()
   {
    var x=document.forms["login"]["username"].value;
    if (x==null || x=="")
    {
      alert("fill the username field ");
      return false;
    }
	
	var y=document.forms["login"]["password"].value;
    if (y==null || y=="")
    {
      alert("fill the password field");
      return false;
    }
  }
  -->
  </script>
 



     </head>
				<body>
		 
				
				
				
				
		 
					 <div id="banner"  style="position:center height:293px; width:500px; ">
					 <h1>University Of Botswana</h1>
					 
					 <hr></hr>
					  <img src="images/images.JPG"  alt="logo" height="150px" width="150px" />
					 
					 </div>
				      <div id="links"  align="right" style=" height:60px; width:500px;">
			        <a href="index.php">Home page</a>
					<a href="my_profile.php"></a>
			        
                    
	                  </div>

                     <div id="content" align="centre" style="  height:300px; width:500px;">

   <form method = "post"  name = "login" action = "login.php" onSubmit = "return validateForm()" align="center">
				<h2>Login</h2>	
		<?php 
			
			if($err_message != "you are not logged in")
			{
				echo "<div class=\"isa_error\">$err_message</div>";
			}
		?> 
				 
				 
				 <fieldset>
				  
					 
					 
								 <label for="Name"> Username:</label><br> 

									<input name = "username" type = "textbox" size = "25" maxlength = "20"/>
									</br>
									
									<label for ="password"> Password:<br> 
						            <input name = "password" type = "password" size = "25" maxlength = "15"/>
						        </br> </label> 
									<input type="submit" value="login" />
									<br />
									<label for = "remember"></label>
			                        <input <?php echo (isset($remember) ? " checked = \"checked\" " : "") ?> id="remember"  name="remember" value="1" type="checkbox" /><br /> &nbsp; Keep me logged in.
									<a href="#">I forgot my password</a>
									</div>
									 
                 </fieldset>
	</form>
<?php 
   //Connecting to the database
	
	$conn = mysql_connect("10.0.19.74","ses04317", "ses04317") or die ("Error connecting to MySQL");
	
	//selecting a database to use
	mysql_select_db("db_ses04317", $conn) or die ("Could not open database");
	
			#check if user is submitting the login form
	if(isset($_POST['login']))
	{
		//log the user in
		$db_link = db_connect();
		$password = mysql_real_escape_string($_POST['password']);
		$username = mysql_real_escape_string($_POST['username']); 
		
		$sql = "SELECT password, email, staff_id,initials, surname FROM csi315_dir_staff WHERE username='$username' AND password='$password'";
		$result = mysql_query($sql) or die( mysql_error() );
		$num_rows = mysql_num_rows($result); 
		
		if($num_rows != 0)
		{
			$row = mysql_fetch_assoc($result);
			$staff_id = $row['staff_id'];
			
			# create session variables
			$_SESSION['s_id'] = $row['staff_id'];
			$_SESSION['name'] = $row['initials']. " ". $row['surname'];
			
			#check if user wants to remain logged in
			if(isset($_POST['remember']))
			{
				setcookie('ub_dir',$username,time() + (60 * 60 * 24 * 365 * 5));
				setcookie('password',$password,time() + (60 * 60 * 24 * 365 * 5));
			}
			
				#redirect to staff profile page
				header('Location: my_profile.php');
				
		}
		else
		{
			$err_message = "You have entered the wrong username or password.";		
		}
		mysql_free_result($result);
		mysql_close($db_link);
		
	}
	else #the user hasn't submitted form
	{
		#the user has logged in, redirect to profile page
		if(isset($_SESSION['s_id']))
		{
			header('Location: my_profile.php');
		}
		#user not logged in, check if remember me cookie saved
		if(isset($_COOKIE['username']))
		{
			#auto login user
			$db_link = db_connect();
			$password = mysql_real_escape_string($_COOKIE['password']);
			$username = mysql_real_escape_string($_COOKIE['username']); 
			
			$sql = "SELECT username, email, staff_id, initials, surname FROM csi315_dir_staff WHERE username ='$username' AND password='$password'";
			$result = mysql_query($sql) or die( mysql_error() );
			$num_rows = mysql_num_rows($result); 
			
			if($num_rows != 0)
			{
				$row = mysql_fetch_assoc($result);
				$staff_id = $row['staff_id'];
				
				//add session variables
				$_SESSION['s_id'] = $row['staff_id'];
				$_SESSION['name'] = $row['initials']. " ". $row['surname'];
				
				header('Location: my_profile.php');
			}
			
		}
	}
?>
	  </div>






	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
<div id="footer"style=" width:500px; " >
Copyright &nbsp;&copy;  Lesego seshabo</div

	 
	    </body>
</html>	 
	 
	 
	 
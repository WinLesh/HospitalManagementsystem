<?php
	// database connection
	require_once("db_connect.php");
	session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
     <head>
         <title> home </title>
	         <meta name= "Keywords"contents= "index">
	         <meta name= "description" contents= "Home Page">
	         <meta name= "author" contents= "L.W.Seshabo">	
   
   <!-- the external style sheet here-->
   <link href="styles/main.css" rel="stylesheet" type="text/css" />
   <style type="text/css">
 body {background-image :url('images/images77.jpg'); background-size: 1750px;	
  }

</style>
     </head>
				<body>
		 
				
				
				
				
		 
							 <div id="banner"  style="position:center height:293px; width:500px; ">
							 <h1>University Of Botswana</h1>
							 <hr>
		</hr>

				              <img src="images/images.JPG"  alt="logo" height="150px" width="150px" />
							 
							 </div>
								  <div id="links"  align="right" style=" height:60px; width:500px;">
								  
								   <?php  //show profile after login 
				if (isset($_SESSION['staff_id']))
				{
					echo "<a class=\"current\" href=\"my_profile.php\">My Profile</a> | ";
					echo "<a class=\"current\" href=\"logout.php\">Log Out</a> | ";
				}
				elseif(isset($_SESSION['admin_uname'])){
					echo "<a class=\"current\" href=\"staff.php\">Admin Page</a> | ";
					echo "<a class=\"current\" href=\"logout.php\">Log Out</a> | ";
				}
			    else{
					echo "<a class=\"current\" href=\"login.php\">Login</a> | ";
				}
				?>
								
								<a href="#">Help</a>&#124
								<a href="search.php">Search</a>
								
								  </div>

							<div id="content" align="centre" style="  height:200px; width:500px;">

		   
						 <form action="index.php" name="searchform" 
		 method="post" align="center">
		
		<h2>home</h2>	
			<fieldset>
			<legend></legend>
			
			<label for = "name">Name:</label> 
			<?php $typedUser= @$_POST['Name'];?>
			<input value="" id = "name" name="name" size="35" maxlength="30" type="text" />
			<br/>
			<br/>
			
			<label for = " department">Department:</label>
			<?php $dep = @$_POST['department']; ?>
			<select name="department" id = "department">
		<option value="Default" <?php $dep == 'Default' ? 'selected' : '' ?> >Select a Department</option>
					<optgroup label="BUSINESS">
					<option  value = "ACCOUNTING AND FINANCE" <?php if($dep == 'ACCOUNTING AND FINANCE') echo 'selected'?>>ACCOUNTING AND FINANCE</option>
					<option  value = "FACULTY OFFICE - BUSINESS" <?php if($dep == 'FACULTY OFFICE - BUSINESS') echo 'selected'?>>FACULTY OFFICE - BUSINESS</option>
					<option  value = "MANAGEMENT" <?php if($dep == 'MANAGEMENT') echo 'selected'?>>MANAGEMENT</option>
					<option  value = "MARKETING" <?php if($dep == 'MARKETING') echo 'selected'?>>MARKETING</option>
					<option  value = "TOURISM AND HOSPITALITY MGT." <?php if($dep == 'TOURISM AND HOSPITALITY MGT.') echo 'selected'?>>TOURISM AND HOSPITALITY MGT.</option>
					</optgroup>
					<optgroup label="CENTRE FOR ACADEMIC DEVELOPMET"><option  value = "COMMUNICATION & STUDY SKILLS"<?php if($dep == 'COMMUNICATION & STUDY SKILLS') echo 'selected'?>>COMMUNICATION &amp; STUDY SKILLS</option>
					<option  value = "DIRECTOR CAD"<?php if($dep == 'DIRECTOR CAD') echo 'selected'?>>DIRECTOR CAD</option>
					<option  value = "PRE-ENTRY SCIENCE"<?php if($dep == 'PRE-ENTRY SCIENCE') echo 'selected'?>>PRE-ENTRY SCIENCE</option>
					<option  value = "PROGRAMME REVIEW(CAD)"<?php if($dep == 'PROGRAMME REVIEW(CAD)') echo 'selected'?>>PROGRAMME REVIEW(CAD)</option> 
					</optgroup>
					<optgroup label="CENTRE FOR CONTINUING ED.">
					<option  value = "CCE-DIRECTORATE"<?php if($dep == 'CCE-DIRECTORATE') echo 'selected'?>>CCE-DIRECTORATE</option>
					</optgroup><optgroup label="EDUCATION"><option  value = "ADULT EDUCATION"<?php if($dep == 'ADULT EDUCATION') echo 'selected'?>>ADULT EDUCATION</option>
					<option  value = "EDUCATIONAL FOUNDATIONS"<?php if($dep == 'EDUCATIONAL FOUNDATIONS') echo 'selected'?>>EDUCATIONAL FOUNDATIONS</option>
					<option  value = "EDUCATIONL TECHNOLOGY"<?php if($dep == 'EDUCATIONL TECHNOLOGY') echo 'selected'?>>EDUCATIONL TECHNOLOGY</option>
					<option  value = "ENGLISH"<?php if($dep == 'ENGLISH') echo 'selected'?>>ENGLISH</option>
					<option  value = "FACULTY OFFICE EDUCATION"<?php if($dep == 'FACULTY OFFICE EDUCATION') echo 'selected'?>>FACULTY OFFICE EDUCATION</option>
					<option  value = "FAMILY AND CONSUMER SCIENCES"<?php if($dep == 'FAMILY AND CONSUMER SCIENCES') echo 'selected'?>>FAMILY AND CONSUMER SCIENCES</option>
					<option  value = "GUIDANCE AND COUNS(SEE-833"<?php if($dep == 'GUIDANCE AND COUNS(SEE-833') echo 'selected'?>>GUIDANCE AND COUNS(SEE-833)</option>
					<option  value = "PHYSICAL EDUCATION"<?php if($dep == 'PHYSICAL EDUCATION') echo 'selected'?>>PHYSICAL EDUCATION</option>
					<option  value = "PRIMARY EDUCATION"<?php if($dep == 'PRIMARY EDUCATION') echo 'selected'?>>PRIMARY EDUCATION</option>
					<option  value = "SCHOOL OF NURSING"<?php if($dep == 'SCHOOL OF NURSING') echo 'selected'?>>SCHOOL OF NURSING</option>
					</optgroup><optgroup label="ENGINEERING AND TECHNOLOGY"><option  value = "ARCHITECTURE AND PLANNING"<?php if($dep == 'ARCHITECTURE AND PLANNING') echo 'selected'?>>ARCHITECTURE AND PLANNING</option>
					<option  value = "C D P U"<?php if($dep == 'C D P U') echo 'selected'?>>C D P U</option>
					<option  value = "CIVIL ENGINEERING"<?php if($dep == 'CIVIL ENGINEERING') echo 'selected'?>>CIVIL ENGINEERING</option>
					<option  value = "FACULTY OFFICE FET"<?php if($dep == 'ACULTY OFFICE FET') echo 'selected'?>>FACULTY OFFICE FET</option>
					<option  value = "INDUSTRIAL DESIGN AND TECHNOLO"<?php if($dep == 'INDUSTRIAL DESIGN AND TECHNOLO') echo 'selected'?>>INDUSTRIAL DESIGN AND TECHNOLO</option>
					<option  value = "MECHANICAL ENGINEERING"<?php if($dep == 'MECHANICAL ENGINEERING') echo 'selected'?>>MECHANICAL ENGINEERING</option>
					<option  value = "TECHNOLOGY AND EDUCATION STUDS"<?php if($dep == 'TECHNOLOGY AND EDUCATION STUDS') echo 'selected'?>>TECHNOLOGY AND EDUCATION STUDS</option>
					</optgroup><optgroup label="HEALTH SCIENCES"><option  value = "DEP OF ENVIRONMENTAL HEALTH"<?php if($dep == 'DEP OF ENVIRONMENTAL HEALTH') echo 'selected'?>>DEP OF ENVIRONMENTAL HEALTH</option>
					<option  value = "FACULTY OFFICE HEALTH SCIENCES"<?php if($dep == 'FACULTY OFFICE HEALTH SCIENCES') echo 'selected'?>>FACULTY OFFICE HEALTH SCIENCES</option>
					</optgroup><optgroup label="HUMANITIES"><option  value = "AFRICAN LANGUAGES & LITERATURE"<?php if($dep == 'AFRICAN LANGUAGES & LITERATURE') echo 'selected'?>>AFRICAN LANGUAGES &amp; LITERATURE</option>
					<option  value = "FACULTY OFFICE HUMANITIES"<?php if($dep == 'FACULTY OFFICE HUMANITIES') echo 'selected'?>>FACULTY OFFICE HUMANITIES</option>
					<option  value = "FRENCH"<?php if($dep == 'FRENCH') echo 'selected'?>>FRENCH</option>
					<option  value = "LIBRARY & INFORMATION STUDIES"<?php if($dep == 'LIBRARY & INFORMATION STUDIES') echo 'selected'?>>LIBRARY &amp; INFORMATION STUDIES</option>
					<option  value = "MEDIA STUDIES"<?php if($dep == 'MEDIA STUDIES') echo 'selected'?>>MEDIA STUDIES</option>
					<option  value = "THEOLOGY AND RELIGIOUS STUDIES"<?php if($dep == 'THEOLOGY AND RELIGIOUS STUDIES') echo 'selected'?>>THEOLOGY AND RELIGIOUS STUDIES</option>
					<option  value = "VISUAL AND PERFORMING ARTS"<?php if($dep == 'VISUAL AND PERFORMING ARTS') echo 'selected'?>>VISUAL AND PERFORMING ARTS</option>
					</optgroup><optgroup label="MEDICINE"><option  value = "SCHOOL OF MEDICINE-DEAN'S OFF"<?php if($dep == "SCHOOL OF MEDICINE-DEAN'S OFF") echo 'selected';?>> SCHOOL OF MEDICINE-DEAN'S OFF</option>
					</optgroup><optgroup label="SCHOOL OF GRADUATE STUDIES"><option  value = "ACCOUNTANCY AND MANA(SEE-751)"<?php if($dep == 'ACCOUNTANCY AND MANA(SEE-751)') echo 'selected'?>>ACCOUNTANCY AND MANA(SEE-751)</option>
					<option  value = "ECONOMICS"<?php if($dep == 'ECONOMICS') echo 'selected'?>>ECONOMICS</option>
					<option  value = "ENVIRONMENTAL SCIENCE"<?php if($dep == 'ENVIRONMENTAL SCIENCE') echo 'selected'?>>ENVIRONMENTAL SCIENCE</option>
					<option  value = "FACULTY OFFICE  GRADUATE STUDS"<?php if($dep == 'FACULTY OFFICE  GRADUATE STUDS') echo 'selected'?>>FACULTY OFFICE  GRADUATE STUDS</option>
					<option  value = "HISTORY"<?php if($dep == 'HISTORY') echo 'selected'?>>HISTORY</option>
					<option  value = "LANGUAGES & SOCIAL SCIENCE ED."<?php if($dep == 'LANGUAGES & SOCIAL SCIENCE ED.') echo 'selected'?>>LANGUAGES &amp; SOCIAL SCIENCE ED.</option>
					<option  value = "MATHEMATICS & SCIENCE EDUCATION"<?php if($dep == 'MATHEMATICS & SCIENCE EDUCATION') echo 'selected'?>>MATHEMATICS &amp; SCIENCE EDUCATION</option>
					<option  value = "POLITICS & ADMINISTRATIVE STUD"<?php if($dep == 'POLITICS & ADMINISTRATIVE STUD') echo 'selected'?>>POLITICS &amp; ADMINISTRATIVE STUD</option>
					<option  value = "SOCIAL WORK"<?php if($dep == 'SOCIAL WORK') echo 'selected'?>>SOCIAL WORK</option>
					<option  value = "SOCIOLOGY"<?php if($dep == 'SOCIOLOGY') echo 'selected'?>>SOCIOLOGY</option>
					<option  value = "STATISTICS"<?php if($dep == 'STATISTICS') echo 'selected'?>>STATISTICS</option>
					</optgroup><optgroup label="SCIENCE"><option  value = "BIOLOGICAL SCIENCES"<?php if($dep == 'BIOLOGICAL SCIENCES') echo 'selected'?>>BIOLOGICAL SCIENCES</option>
					<option  value = "CHEMISTRY"<?php if($dep == 'CHEMISTRY') echo 'selected'?>>CHEMISTRY</option>
					<option  value = "COMPUTER SCIENCE"<?php if($dep == 'COMPUTER SCIENCE') echo 'selected'?>>COMPUTER SCIENCE</option>
					<option  value = "FACULTY OFFICE SCIENCES"<?php if($dep == 'FACULTY OFFICE SCIENCES') echo 'selected'?>>FACULTY OFFICE SCIENCES</option>
					<option  value = "GEOLOGY"<?php if($dep == 'GEOLOGY') echo 'selected'?>>GEOLOGY</option>
					<option  value = "MATHEMATICS"<?php if($dep == 'MATHEMATICS') echo 'selected'?>>MATHEMATICS</option>
					<option  value = "PHYSICS"<?php if($dep == 'PHYSICS') echo 'selected'?>>PHYSICS</option>
					</optgroup><optgroup label="SOCIAL SCIENCES"><option  value = "FACULTY OFFICE SOCIAL SCIENCE"<?php if($dep == 'FACULTY OFFICE SOCIAL SCIENCE') echo 'selected'?>>FACULTY OFFICE SOCIAL SCIENCE</option>
					<option  value = "LAW"<?php if($dep == 'LAW') echo 'selected';?>>LAW</option>
					<option  value = "POPULATION STUDIES"<?php if($dep == 'POPULATION STUDIES') echo 'selected'?>>POPULATION STUDIES</option>
					<option  value = "PSYCHOLOGY"<?php if($dep == 'PSYCHOLOGY') echo 'selected'?>>PSYCHOLOGY</option>
					</optgroup>	</select>	
<br/>
<br/>

	<input name="search" value="Find" size="6" type="submit" />
		&nbsp; &nbsp; <input name="reset" value="Start over" size="10" type="reset" />	<br />
		</fieldset>
	</form>

<div>
	  <?php 
				if(isset($_POST['username'])){
					$con = mysql_connect("10.0.19.74","ses04317","ses04317");
					if (!$con)
					{
						die('Could not connect: ' . mysql_error());
					}
					
					mysql_select_db("db_ses04317", $con);

					
					$sql = "SELECT * FROM staff WHERE surname LIKE '%".$_POST['username']."%'".
						"or email LIKE '%".$_POST['username']."%'". "or username LIKE '%".$_POST['username']."%'";
					
					$result = mysql_query($sql,$con)or die (mysql_error());

					if (mysql_num_rows($result)==0){ 
						echo "No info. found for ".$_POST['username']; 
					}
					
					else if ($_POST['username'] == "") {
						echo "Please type in something and search !";
					}
					
					else{
						echo "Search results for ".$_POST['username'];
						echo "<table border='1' align='left'>
							<tr>
								<th>Title</th>
								<th>Initials</th>
								<th>Lastname</th>
								<th>Phone</th>
								<th>Email</th>
								<th>Office</th>
								<th>Department</th>
								<th>Operation</th>
							</tr>";

						while($row = mysql_fetch_array($result))
						{
							echo "<tr>
									<td>" . $row['title'] . "</td>
									<td>" . $row['initials'] . "</td>
									<td>" . $row['surname'] . "</td>
									<td>" . $row['phone'] . "</td>
									<td>" . $row['email'] . "</td>
									<td>" . $row['office'] . "</td>
									<td>" . $row['department_id'] . "</td>
									<td><a href='send_mail.php'>'Send Mail'</a></td>
								</tr>";
								
						}
						echo "</table>";
					}
					mysql_close();
				}
				else{
					echo "Please type in the search box above.";
				}
				
			?>
			
	  </div>
	 
				
			<?php
					// Display the results
					while($row = mysql_fetch_assoc($result)){
						$user = $row['initials']." ".$row['surname'];
						$dept_name = $sDepartment;
						$phone = $row['phone'];
						$office= $row['office'];
						$email = $row['email'];
						echo "<tr><td>$user</td><td>$dept_name </td><td>$phone</td><td>$office</td><td align='center'><a href='send_mail.php'> <img src='images/send.jpg' alt='mail' width='23.4' height='18'></td></tr>";
					}
				   
				
			?>
				</table>
			 <br/><br/>




	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
<div id="footer"style="  width:500px; " >
Copyright &nbsp;&copy; Lesego seshabo</div

	 
	    </body>
</html>	 
	 
	 
	 
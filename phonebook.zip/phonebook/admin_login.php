<?php
	// database connection
	require_once("db_connect.php");
	session_start();
	
	if(isset($_SESSION['admin_uname']))
	{
		header("Location: staff.php");
	}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
     <head>
         <title> phone directory </title>
	         <meta name= "Keywords"contents= "Login">
	         <meta name= "description" contents= "Admin">
	         <meta name= "author" contents= "L.W.Seshabo">	
   
   <!-- the external style sheet here-->
   <script language="javascript" src="js/validate.js" type="text/javascript"></script>
   <link href="styles/main.css" rel="stylesheet" type="text/css" />
   <style type="text/css">
 body {background-image :url('images/images77.jpg'); background-size: 1750px;
  }
 </style>
<script>
	<!--
	function validateForm()
   {
    var x=document.forms["admin_login"]["username"].value;
    if (x==null || x=="")
    {
      alert("fill the username field ");
      return false;
    }
	
	var y=document.forms["admin_login"]["password"].value;
    if (y==null || y=="")
    {
      alert("fill the password field");
      return false;
    }
  }
  -->
  </script>


     </head>
				<body>
		 
		                     <div id="banner"  style="position:center height:293px; width:500px; ">
							 <h1>University Of Botswana</h1>
							 <hr>
		</hr>

							 <img src="images/images.JPG"  alt="logo" height="150px" width="150px" />
							 
							 </div>
								  <div id="links"  align="right" style=" height:60px; width:500px;">
								<a href="staff.php">staff</a> 
								
								
								  </div>

							 <div id="content" align="centre" style="  height:200px; width:500px;">

		   <form method = "post"  align="centre" method = "POST" action = "admin_login.php" onSubmit = "return validateForm()" name="admin_login" >
						 <fieldset>
						  
							 
							 
										 <label for="username"> username:</label><br /> 

											<input name = "username" type = "text" size = "25" maxlength = "20"/>
											</br>
											<label for="password" >password:</label><br />
											
											<input name = "password" type = "password" maxlength="25" size="15" />
											</br>	
											
											<input type="submit" value="login" name="submit" /> 
											<input type="reset" value="clear" />
											</div>
											 
                 </fieldset>
				 
	</form>
		



	  <?php 
   //Connecting to the database
	
	$conn = mysql_connect("localhost","ses0317", "ses04317") or die ("Error connecting to MySQL");
	
	//selecting a database to use
	mysql_select_db("db_ses04317", $conn) or die ("Could not open database");
	
	//Aquiring the username and password from the log in form
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	
	
	$result = "SELECT username, password FROM admins WHERE username = '$username'  AND password = '$password'";
	
	$query = mysql_query($result);
	
		if($query)
		{
			if (mysql_num_rows($query) > 0 )
			{
				header("Location: staff.php");	
			}
			//if ()
			/*{
				header("Location: loginFailed.php");
			}*/
		}
		else
        {
		die ("Query failed");
		}
	

		
	mysql_close($conn);
	
    ?>		



	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
<div id="footer"style="  width:500px; " >
Copyright &nbsp;&copy; Lesego seshabo</div

	 
	    </body>
</html>	 
	 
